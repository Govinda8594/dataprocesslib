package com.dataprocess.assignment;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.*;
import java.util.stream.Stream;

public class EventAggregator {

    public static ConcurrentMap<String, EventStats> aggregate(Stream<Event> events) {
        ConcurrentMap<String, EventStats> statsMap = new ConcurrentHashMap<>(); // valid event
        ConcurrentMap<String, Set<Long>> seenTimestamps = new ConcurrentHashMap<>(); // handle duplicate

        events.parallel()
              .filter(e ->
                      e.value() >= 0 && !Double.isNaN(e.value())) // valid events
              .filter(e -> seenTimestamps
                           .computeIfAbsent(e.id(), k -> new HashSet<>())
                           .add(e.timestamp())) // deduplication
              .forEach(e -> statsMap
                           .computeIfAbsent(e.id(), EventStats::new)
                           .addEvent(e));

        return statsMap;
    }
}