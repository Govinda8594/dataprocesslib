package com.dataprocess.assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.stream.Stream;

@SpringBootApplication
public class AssignmentApplication {

	public static void main(String[] args) {
            Stream<Event> stream = Stream.of(
                    new Event("Event 1", 1000L, 10.0),
                    new Event("Event 1", 2000L, 20.0),
                    new Event("Event 1", 2000L, 20.0), // duplicate
                    new Event("Event 2", 1500L, 30.0),
                    new Event("Event 2", 2500L, -5.0)  // invalid
            );

            var result = EventAggregator.aggregate(stream);

            result.forEach((id, stats) -> {
                System.out.println("id: " + id);
                System.out.println("Count: " + stats.getCount());
                System.out.println("Min timestamp: " + stats.getMinTimestamp());
                System.out.println("Max timestamp: " + stats.getMaxTimestamp());
                System.out.println("Average: " + stats.getAverage());
                System.out.println();
            });

//		SpringApplication.run(AssignmentApplication.class, args);
	}

}
