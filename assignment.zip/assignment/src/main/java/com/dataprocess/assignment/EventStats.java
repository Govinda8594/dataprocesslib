package com.dataprocess.assignment;

public class EventStats {
    private final String id;
    private long count;
    private long minTimestamp = Long.MAX_VALUE;
    private long maxTimestamp = Long.MIN_VALUE;
    private double sum;

    public EventStats(String id) {
        this.id = id;
    }

    public synchronized void addEvent(Event e) {
        count++;
        sum += e.value();
        minTimestamp = Math.min(minTimestamp, e.timestamp());
        maxTimestamp = Math.max(maxTimestamp, e.timestamp());
    }

    // assume
    public double getAverage() {
        return count == 0 ? 0.0 : sum / count;
    }

    public long getCount() {
        return count;
    }

    public long getMaxTimestamp() {
        return maxTimestamp;
    }

    public long getMinTimestamp() {
        return minTimestamp;
    }
}
