package com.dataprocess.assignment;

// Event record
public record Event(String id, long timestamp, double value) {}

