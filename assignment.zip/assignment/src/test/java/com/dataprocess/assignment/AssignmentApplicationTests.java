package com.dataprocess.assignment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.stream.Stream;

@SpringBootTest
class AssignmentApplicationTests {

    // empty strema
        @Test
        void testEmptyStream() {
            var result = EventAggregator.aggregate(Stream.empty());
            Assertions.assertTrue(result.isEmpty());
        }
    // valid single event
        @Test
        void testSingleValidEvent() {
            Event e = new Event("Event 1", 1000L, 10.0);
            var result = EventAggregator.aggregate(Stream.of(e));
            Assertions.assertEquals(1, result.get("Event 1").getCount());
            Assertions.assertEquals(10.0, result.get("Event 1").getAverage());
        }
    // duplicate event
        @Test
        void testDuplicateEvents() {
            Event e1 = new Event("Event 1", 1000L, 10.0);
            Event e2 = new Event("Event 1", 1000L, 20.0); // duplicate timestamp
            var result = EventAggregator.aggregate(Stream.of(e1, e2));
            Assertions.assertEquals(1, result.get("Event 1").getCount()); // only first counted
        }
    // invalid event
        @Test
        void testInvalidEvents() {
            Event e1 = new Event("A", 1000L, -5.0);
            Event e2 = new Event("A", 2000L, Double.NaN);
            var result = EventAggregator.aggregate(Stream.of(e1, e2));
            Assertions.assertTrue(result.isEmpty());
        }

}
